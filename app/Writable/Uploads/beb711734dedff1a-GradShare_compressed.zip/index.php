<?php

error_reporting(E_ALL);
ini_set("display_errors", 1);

// Set the allowed file types
$allowedTypes = ["image/jpeg", "image/png", "image/gif", "application/pdf"];
// Define the upload directory
$uploadDir = __DIR__ . "/uploads/";

// Create the uploads directory if it doesn't exist
if (!is_dir($uploadDir)) {
  mkdir($uploadDir, 0755, true);
}

// Handle different HTTP methods
$requestMethod = $_SERVER["REQUEST_METHOD"];

switch ($requestMethod) {
  case "POST":
    handleFileUpload();
    break;
  default:
    sendResponse(405, "Method Not Allowed");
}

function handleFileUpload()
{
  global $allowedTypes, $uploadDir;

  if (!isset($_FILES["file"])) {
    sendResponse(400, "No file uploaded");
    return;
  }

  $file = $_FILES["file"];

  // Check for upload errors
  if ($file["error"] !== UPLOAD_ERR_OK) {
    sendResponse(500, "File upload failed with error code " . $file["error"]);
    return;
  }

  // Check file type
  if (!in_array($file["type"], $allowedTypes)) {
    sendResponse(400, "Unsupported file type");
    return;
  }

  // Generate a unique file name
  $fileName = uniqid() . "-" . basename($file["name"]);
  $filePath = $uploadDir . $fileName;

  // Move the uploaded file
  if (move_uploaded_file($file["tmp_name"], $filePath)) {
    sendResponse(200, "File uploaded successfully", ["file_name" => $fileName]);
  } else {
    sendResponse(500, "Failed to move uploaded file");
  }
}

function sendResponse($statusCode, $statusMessage, $data = null)
{
  http_response_code($statusCode);
  header("Content-Type: application/json");
  $response = [
    "status" => $statusCode,
    "message" => $statusMessage,
  ];

  if ($data) {
    $response["data"] = $data;
  }

  echo json_encode($response);
  exit();
}
